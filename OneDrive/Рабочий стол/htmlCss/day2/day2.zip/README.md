# Decode Marathon study project

This project was developed for learning purposes.

## Improved skills:
- HTML
- CSS


You could browse [demo]()


## License
[MIT](https://choosealicense.com/licenses/mit/)